package com.testleaf.web.element;

public interface Link extends Element{

	void click();
	String getHref();
	
}
